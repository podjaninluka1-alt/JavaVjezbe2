package Proojekat2;


public class Player extends GameObject {

    private String name = "Igrac";
    private int health = 100;

    public Player(String name, int x, int y, int width, int height, int health) {
        super(x, y, width, height);
        setName(name);
        setHealth(health);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name.trim().equals("")) {
            System.out.println("Ime igraca ne smije biti prazno!");
            return;
        }

        this.name = formatirajTekst(name);
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        if (health < 0 || health > 100) {
            System.out.println("Health mora biti izmedju 0 i 100!");
        } else {
            this.health = health;
        }
    }

    public String toString() {
        return "Player[" + name + "] @ (" + getX() + "," + getY() + ") " + getWidth() + "x" + getHeight()
                + " HP=" + health;
    }
}