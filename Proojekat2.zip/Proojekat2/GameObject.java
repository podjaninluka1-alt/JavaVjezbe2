package Proojekat2;

// LUKA PODJANIN 22/081 I ANASTASIJA BUBANJA 25/089

public  class GameObject {
    private int x;
    private int y;
    private int width = 1;
    private int height = 1;

    public GameObject(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        setWidth(width);
        setHeight(height);
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        if (width <= 0) {
            System.out.println("Sirina mora biti veca od nule!");
        } else {
            this.width = width;
        }
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        if (height <= 0) {
            System.out.println("Visina mora biti veca od nule!");
        } else {
            this.height = height;
        }
    }

   
    public boolean intersects(GameObject other) {
        if (other == null) {
            return false;
        }
        return x < other.x + other.width
                && x + width > other.x
                && y < other.y + other.height
                && y + height > other.y;
    }

   
    protected static String formatirajTekst(String tekst) {
        tekst = tekst.trim();

        String novi = "";
        boolean pocetakRijeci = true;

        for (int i = 0; i < tekst.length(); i++) {
            char c = tekst.charAt(i);

            if (c == ' ') {
                if (pocetakRijeci == false) {
                    novi = novi + " ";
                }
                pocetakRijeci = true;
            } else {
                if (pocetakRijeci == true) {
                    novi = novi + Character.toUpperCase(c);
                } else {
                    novi = novi + Character.toLowerCase(c);
                }
                pocetakRijeci = false;
            }
        }

        return novi;
    }

    public String toString() {
        return "GameObject @ (" + x + "," + y + ") " + width + "x" + height;
    }
}