package Proojekat2;

// LUKA PODJANIN 22/081 I ANASTASIJA BUBANJA 25/089

public class GameTest {
    public static void main(String[] args) {

        Player p = new Player("  marko   petrovic ", 10, 5, 32, 32, 85);
        Game game = new Game(p);

        Enemy orc = new MeleeEnemy("Orc", 100, 100, 20, 20, 30, 80);
        Enemy goblin = Game.napraviIzStringa("Goblin;12,5;16x16;20;60");
        Enemy boss = new BossEnemy("goblin king", 12, 5, 32, 32, 25, 120);

        game.addEnemy(orc);
        game.addEnemy(goblin);
        game.addEnemy(boss);

        System.out.println("=== Svi neprijatelji ===");
        game.printEnemies();

        System.out.println("\n=== Neprijatelji koji sadrze 'gob' ===");
        for (Enemy e : game.findByType("gob")) {
            System.out.println(e);
        }

        System.out.println("\n=== Prije sudara ===");
        System.out.println(p);

        game.resolveCollisions();

        System.out.println("\n=== Poslije sudara ===");
        System.out.println(p);

        System.out.println("\n=== Event log ===");
        game.printEventLog();
    }
}