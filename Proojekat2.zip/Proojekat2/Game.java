package Proojekat2;

import java.util.ArrayList;

public class Game {
    private Player player;
    private ArrayList<Enemy> enemies = new ArrayList<Enemy>();
    private ArrayList<String> eventLog = new ArrayList<String>();

    public Game(Player player) {
        this.player = player;
    }

    public Player getPlayer() {
        return player;
    }

    public ArrayList<Enemy> getEnemies() {
        return enemies;
    }

    public ArrayList<String> getEventLog() {
        return eventLog;
    }

    public void addEnemy(Enemy e) {
        enemies.add(e);
        eventLog.add("ADD: " + e.getClass().getSimpleName() + " " + e.getType() + " added");
    }

    public boolean checkCollision(Player p, Enemy e) {
        return p.intersects(e);
    }

    public void decreaseHealth(Player p, Enemy e) {
        int stariHealth = p.getHealth();
        int steta = e.izracunajStetu();
        int noviHealth = stariHealth - steta;

        if (noviHealth < 0) {
            noviHealth = 0;
        }

        p.setHealth(noviHealth);

        eventLog.add("HIT: Player by " + e.getType() + " for " + steta
                + " -> HP " + stariHealth + " -> " + noviHealth);
    }

    public ArrayList<Enemy> findByType(String query) {
        query = query.trim().toLowerCase();

        ArrayList<Enemy> rezultat = new ArrayList<Enemy>();
        for (Enemy e : enemies) {
            if (e.getType().toLowerCase().contains(query)) {
                rezultat.add(e);
            }
        }
        return rezultat;
    }

    public ArrayList<Enemy> collidingWithPlayer() {
        ArrayList<Enemy> rezultat = new ArrayList<Enemy>();
        for (Enemy e : enemies) {
            if (checkCollision(player, e)) {
                rezultat.add(e);
            }
        }
        return rezultat;
    }

    public void resolveCollisions() {
        for (Enemy e : collidingWithPlayer()) {
            decreaseHealth(player, e);
        }
    }

    public void printEnemies() {
        for (Enemy e : enemies) {
            System.out.println(e);
        }
    }

    public void printEventLog() {
        for (String log : eventLog) {
            System.out.println(log);
        }
    }

    public static Enemy napraviIzStringa(String tekst) {
        String[] dijelovi = tekst.split(";");

        String tip = dijelovi[0];

        String[] pozicija = dijelovi[1].split(",");
        int x = Integer.parseInt(pozicija[0]);
        int y = Integer.parseInt(pozicija[1]);

        String[] dimenzije = dijelovi[2].split("x");
        int sirina = Integer.parseInt(dimenzije[0]);
        int visina = Integer.parseInt(dimenzije[1]);

        int damage = Integer.parseInt(dijelovi[3]);
        int health = Integer.parseInt(dijelovi[4]);

        if (dijelovi.length > 5 && dijelovi[5].trim().equalsIgnoreCase("boss")) {
            return new BossEnemy(tip, x, y, sirina, visina, damage, health);
        }
        return new MeleeEnemy(tip, x, y, sirina, visina, damage, health);
    }
}